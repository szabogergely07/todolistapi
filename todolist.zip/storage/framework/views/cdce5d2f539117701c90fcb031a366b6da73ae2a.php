<?php echo Form::open(['url' => 'contact/submit']); ?>

    <div class="form-group">
		<?php echo e(Form::label('name', 'Name')); ?>

		<?php echo e(Form::text('username')); ?>

    </div>
    
    	<?php if(count($errors) > 0): ?>
			
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="alert alert-danger">
					<?php echo e($error); ?>

				</div>		
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
    	<?php endif; ?>
    
    <?php echo e(Form::submit('Click Me!')); ?>

<?php echo Form::close(); ?>


<div class="container">
	<?php $__currentLoopData = $messages->all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($message->username); ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>